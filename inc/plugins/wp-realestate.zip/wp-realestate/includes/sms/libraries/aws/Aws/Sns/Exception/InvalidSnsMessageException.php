<?php
namespace Aws\Sns\Exception;

/**
 * Runtime exception thrown by the SNS Message Validator.
 */
class InvalidSnsMessageException extends \RuntimeException
{
}
