<div id="property-section-google-places" class="property-section property-google-places" data-property_id="<?php the_ID(); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce( 'wp-realestate-property-google-places-nonce' )); ?>">
	
    <div class="property-section property-yelp-places">
		<div class="property-section-heading">
			<h3><?php esc_html_e('Google Nearby Places', 'homeo'); ?></h3>
		</div>
		<div class="property-section-content"></div>
	</div>
</div>

