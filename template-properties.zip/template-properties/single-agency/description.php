<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
global $post;


?>
<div class="description inner">
    <div class="description-inner">
        <?php the_content(); ?>
    </div>
</div>